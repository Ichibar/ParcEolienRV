Thank you for purchasing AQUAS!
The current version is 1.3!

For video tutorials and the latest manual please visit the following link:

https://dogmaticgames.wordpress.com/products/aquas-water-shader-set/tutorials/

Have Fun!